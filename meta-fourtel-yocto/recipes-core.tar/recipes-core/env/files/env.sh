#!/bin/sh
export NVIDIA_DRIVER_CAPABILITIES=all

